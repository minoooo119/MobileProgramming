package edu.skku.cs.pa1

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class WordleWordAdapter(val data:ArrayList<WordleWord>,val context: Context) :BaseAdapter(){
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater=
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val generatedView=inflater.inflate(R.layout.item_wordleword,null)
        val textView1=generatedView.findViewById<TextView>(R.id.textView1)
        val textView2=generatedView.findViewById<TextView>(R.id.textView2)
        val textView3=generatedView.findViewById<TextView>(R.id.textView3)
        val textView4=generatedView.findViewById<TextView>(R.id.textView4)
        val textView5=generatedView.findViewById<TextView>(R.id.textView5)
        val letter1=data[p0].letter1
        val letter2=data[p0].letter2
        val letter3=data[p0].letter3
        val letter4=data[p0].letter4
        val letter5=data[p0].letter5
        textView1.text=letter1.uppercase()
        textView2.text=letter2.uppercase()
        textView3.text=letter3.uppercase()
        textView4.text=letter4.uppercase()
        textView5.text=letter5.uppercase()

        val input=data[p0].letter1+data[p0].letter2+data[p0].letter3+data[p0].letter4+data[p0].letter5
        //랜덤한거 나옴
        val random_word=data[p0].random_word
        //val random_word="minho"
        for(i in 0 until input.length){
            if(input[i]==random_word[i]){
                if(i==0){
                    textView1.background = ColorDrawable(Color.parseColor("#FF99F691"))
                    textView1.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==1){
                    textView2.background = ColorDrawable(Color.parseColor("#FF99F691"))
                    textView2.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==2){
                    textView3.background = ColorDrawable(Color.parseColor("#FF99F691"))
                    textView3.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==3){
                    textView4.background = ColorDrawable(Color.parseColor("#FF99F691"))
                    textView4.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==4){
                    textView5.background = ColorDrawable(Color.parseColor("#FF99F691"))
                    textView5.setTextColor(Color.parseColor("#FF000000"))
                }
            }else if(random_word.contains(input[i])){
                if(i==0){
                    textView1.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
                    textView1.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==1){
                    textView2.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
                    textView2.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==2){
                    textView3.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
                    textView3.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==3){
                    textView4.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
                    textView4.setTextColor(Color.parseColor("#FF000000"))
                }
                else if(i==4){
                    textView5.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
                    textView5.setTextColor(Color.parseColor("#FF000000"))
                }
            }else{
                if(i==0){
                    textView1.background = ColorDrawable(Color.parseColor("#787C7E"))
                    textView1.setTextColor(Color.parseColor("#FFFFFFFF"))
                }
                else if(i==1){
                    textView2.background = ColorDrawable(Color.parseColor("#787C7E"))
                    textView2.setTextColor(Color.parseColor("#FFFFFFFF"))
                }
                else if(i==2){
                    textView3.background = ColorDrawable(Color.parseColor("#787C7E"))
                    textView3.setTextColor(Color.parseColor("#FFFFFFFF"))
                }
                else if(i==3){
                    textView4.background = ColorDrawable(Color.parseColor("#787C7E"))
                    textView4.setTextColor(Color.parseColor("#FFFFFFFF"))
                }
                else if(i==4){
                    textView5.background = ColorDrawable(Color.parseColor("#787C7E"))
                    textView5.setTextColor(Color.parseColor("#FFFFFFFF"))
                }

            }
        }




        return generatedView

    }
}