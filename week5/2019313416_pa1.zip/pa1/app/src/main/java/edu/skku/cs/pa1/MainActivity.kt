package edu.skku.cs.pa1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ListView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val assetManager = applicationContext.assets
        val inputStream = assetManager.open("wordle_words.txt")// wordle_words.txt 파일 가져오기
        val wordList = inputStream.bufferedReader().readLines() // 모든 줄을 리스트로 가져오기
        val randomLine = wordList.indices.random()

        val randomWord = wordList[randomLine]
        //val randomWord="money"
        var edit_view=findViewById<EditText>(R.id.editText1)
        var submit_button=findViewById<Button>(R.id.button)
        //for WordleWord Adapter
        val wordleword_items=ArrayList<WordleWord>()
        //for Letter Adapter
        val letter_items_green=ArrayList<Letter>()
        val letter_items_yellow=ArrayList<Letter>()
        val letter_items_grey=ArrayList<Letter>()

        submit_button.setOnClickListener{
            if(edit_view.text.toString() in wordList){
                wordleword_items.add(WordleWord(edit_view.text[0].toString(),edit_view.text[1].toString(),
                    edit_view.text[2].toString(),edit_view.text[3].toString(),edit_view.text[4].toString(),randomWord))
                val user_input=edit_view.text.toString()
                var color=""
                val green_Adapter=LetterAdapter(letter_items_green,applicationContext)
                val yellow_Adapter=LetterAdapter(letter_items_yellow,applicationContext)
                val grey_Adapter=LetterAdapter(letter_items_grey,applicationContext)

                val GrayListView=findViewById<ListView>(R.id.GrayListView)
                val YellowListView=findViewById<ListView>(R.id.YellowListView)
                val GreenListView=findViewById<ListView>(R.id.GreenListView)
                for(i in 0..4){
                    if (randomWord.contains(user_input[i])) {
                    // 맞춘 글자인 경우
                        if (randomWord[i] == user_input[i]) {
                            color="green"
                            if(!letter_items_green.contains(Letter(user_input[i].toString(),color))){
                                letter_items_green.add(Letter(user_input[i].toString(),color))
                                GreenListView.adapter=green_Adapter
                                if(letter_items_yellow.contains(Letter(user_input[i].toString(),"yellow"))){
                                    val nameToRemove = user_input[i].toString()
                                    val elementToRemove = letter_items_yellow.find { it.letter == nameToRemove }
                                    letter_items_yellow.remove(elementToRemove)
                                    yellow_Adapter.notifyDataSetChanged()
                                    YellowListView.adapter = yellow_Adapter
                                }
                            }
                        }
                        // 맞춘 글자가 있지만 위치가 틀린 경우
                        else {
                            color="yellow"
                            if (!letter_items_yellow.contains(Letter(user_input[i].toString(),color))
                                && !letter_items_green.contains(Letter(user_input[i].toString(),"green"))) {
                                letter_items_yellow.add(Letter(user_input[i].toString(),color))
                                YellowListView.adapter = yellow_Adapter
                            }
                        }
                    }
                // 맞춘 글자가 없는 경우
                    else {
                        color="grey"
                        if(!letter_items_grey.contains(Letter(user_input[i].toString(),color))){
                            letter_items_grey.add(Letter(user_input[i].toString(),color))
                            GrayListView.adapter=grey_Adapter
                        }
                    }
                }




                val myAdapter=WordleWordAdapter(wordleword_items,applicationContext)
                val listView=findViewById<ListView>(R.id.listViewWordleWord)

                listView.adapter=myAdapter
                edit_view.text.clear()
                //text사용 후에 clear
            }else{
                Toast.makeText(applicationContext,"Word ‘<User_input>’ not in dictionary!", Toast.LENGTH_LONG).show()
                edit_view.text.clear()
                //clear해주기
            }

        }


    }
}