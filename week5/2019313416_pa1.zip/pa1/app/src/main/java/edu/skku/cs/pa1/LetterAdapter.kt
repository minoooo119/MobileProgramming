package edu.skku.cs.pa1

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class LetterAdapter(val data:ArrayList<Letter>,val context: Context):BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater=
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val generatedView=inflater.inflate(R.layout.items_letter,null)
        val oneLetter=generatedView.findViewById<TextView>(R.id.textView)

        val letter=data[p0].letter
        val color=data[p0].color
        if(color=="green"){
            oneLetter.text = letter.uppercase()
            oneLetter.background = ColorDrawable(Color.parseColor("#FF99F691"))
            oneLetter.setTextColor(Color.parseColor("#FF000000"))
        }else if(color=="yellow"){
            oneLetter.text = letter.uppercase()
            oneLetter.background = ColorDrawable(Color.parseColor("#FFFFE46F"))
            oneLetter.setTextColor(Color.parseColor("#FF000000"))
        }else{
            oneLetter.text = letter.uppercase()
            oneLetter.background = ColorDrawable(Color.parseColor("#787C7E"))
            oneLetter.setTextColor(Color.parseColor("#FFFFFFFF"))
        }


        return generatedView
    }
}