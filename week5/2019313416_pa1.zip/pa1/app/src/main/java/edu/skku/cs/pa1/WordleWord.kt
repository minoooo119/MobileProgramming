package edu.skku.cs.pa1

class WordleWord(
    val letter1:String,
    val letter2:String,
    val letter3:String,
    val letter4:String,
    val letter5:String,
    val random_word:String
) {
}