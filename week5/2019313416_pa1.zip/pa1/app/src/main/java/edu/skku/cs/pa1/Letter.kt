package edu.skku.cs.pa1

class Letter (
    val letter:String,
    val color:String
        ){
    override fun equals(other: Any?): Boolean {
        if (other is Letter) {
            return letter == other.letter && color == other.color
        }
        return super.equals(other)
    }

}